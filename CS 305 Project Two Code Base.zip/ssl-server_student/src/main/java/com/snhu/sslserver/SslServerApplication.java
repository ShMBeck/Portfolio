package com.snhu.sslserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

@SpringBootApplication
public class SslServerApplication {

    public static void main(String[] args) {
        SpringApplication.run(SslServerApplication.class, args);
    }
}

// Controller to handle the checksum route
@RestController
class ChecksumController {

    // This is the static data string
    private static final String DATA = "Hello World Check Sum by Shane Beck!";

    // Define the route that returns the checksum
    @GetMapping("/checksum")
    public String getChecksum() {
        try {
            // Create a MessageDigest instance for SHA-256
            MessageDigest digest = MessageDigest.getInstance("SHA-256");

            // Generate the checksum (hash)
            byte[] hash = digest.digest(DATA.getBytes());

            // Convert the byte array into a hexadecimal string
            StringBuilder hexString = new StringBuilder();
            for (byte b : hash) {
                hexString.append(String.format("%02x", b));
            }

            // Return the original data and its checksum
            return "Data: " + DATA + "\nChecksum: " + hexString.toString();

        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
            return "Error generating checksum";
        }
    }
}