package com.snhu.sslserver;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.ResponseEntity;

import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
class SslServerApplicationTests {

    @Autowired
    private TestRestTemplate restTemplate;

    @Test
    void contextLoads() {
    }

    @Test
    void testChecksumEndpoint() {
        // Send a GET request to the /checksum endpoint
        ResponseEntity<String> response = restTemplate.getForEntity("/checksum", String.class);

        // Verify that the response contains the expected static data string
        assertThat(response.getBody()).contains("Hello World Check Sum by Shane Beck!");

        // Verify that the response contains a checksum
        assertThat(response.getBody()).contains("Checksum: ");
    }
}